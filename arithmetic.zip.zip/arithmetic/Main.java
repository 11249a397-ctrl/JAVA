import add.Add;
import sub.Sub;
import mul.Mul;
import div.Div;

public class Main {
    public static void main(String[] args) {

        Add a = new Add();
        Sub s = new Sub();
        Mul m = new Mul();
        Div d = new Div();

        System.out.println("Addition: " + a.addition(20, 10));
        System.out.println("Subtraction: " + s.subtraction(20, 10));
        System.out.println("Multiplication: " + m.multiplication(20, 10));
        System.out.println("Division: " + d.division(20, 10));
    }
}
