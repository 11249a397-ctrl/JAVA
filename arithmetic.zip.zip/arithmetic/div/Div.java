package div;

public class Div {
    public int division(int a, int b) {
        return a / b;
    }
}
