package sub;

public class Sub {
    public int subtraction(int a, int b) {
        return a - b;
    }
}
